This is the UART-SPI conversion tool.

Without writing the new code, you can try any AT commands and ESC sequence.

Please don't Arduino IDE Serial monitor, because it does not send ESC (0x1b) character.

Please use Teraterm.
